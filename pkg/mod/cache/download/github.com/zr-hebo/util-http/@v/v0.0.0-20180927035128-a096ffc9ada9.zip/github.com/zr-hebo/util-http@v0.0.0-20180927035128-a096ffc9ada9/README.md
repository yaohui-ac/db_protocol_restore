# easyhttp
an easy http receiver and sender implement with golang
