# Changelog

See https://msgpack.uptrace.dev/changelog/
