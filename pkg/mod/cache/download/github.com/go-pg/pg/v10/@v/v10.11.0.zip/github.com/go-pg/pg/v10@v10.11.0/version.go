package pg

// Version is the current release version.
func Version() string {
	return "10.11.0"
}
